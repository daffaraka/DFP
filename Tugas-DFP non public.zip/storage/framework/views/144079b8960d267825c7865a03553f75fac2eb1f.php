
<?php $__env->startSection('content-admin'); ?>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nama Produk</label>
		<input type="text" class="form-control" name="nama" value="">
	</div>
	<div class="form-group">
		<label>Harga (Rp)</label>
		<input type="text" class="form-control" name="harga" value="">
	</div>
	<div class="form-group">
		<img src="../admin/foto_produk/" width="200">
	</div>
	<div class="form-group">
		<label>Ganti Foto Produk</label>
		<input type="file" class="form-control" name="foto">
	</div>
	<button class="btn btn-primary" name="ubah">Ubah</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/admin/product-edit.blade.php ENDPATH**/ ?>