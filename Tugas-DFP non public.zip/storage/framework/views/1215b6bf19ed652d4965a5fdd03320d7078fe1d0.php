
<?php $__env->startSection('content-admin'); ?>
<h2>Tambah Produk</h2>

<form method="post" enctype="multipart/form-data" action="<?php echo e(route('admin.product-store')); ?>">
	<?php echo csrf_field(); ?>
	<div class="form-group">
		<label>Nama</label>
		<input type="text" class="form-control" name="nama_produk">
	</div>
	<div class="form-group">
		<label>Harga(Rp)</label>
		<input type="number" class="form-control" name="harga_produk">
	</div>
	<div class="form-group">
		<label>Foto</label>
		<input type="file" class="form-control" name="foto_produk">
	</div>
	<button class="btn btn-primary" name="save">Simpan</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/admin/product-tambah.blade.php ENDPATH**/ ?>