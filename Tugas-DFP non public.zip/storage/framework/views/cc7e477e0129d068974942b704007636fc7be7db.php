
<?php $__env->startSection('content-admin'); ?>

<h2>Data Produk</h2>

        <table class="table table-bordered">
            <thead>
                <tr>
                
                    <th>Id</th>
                    <th>Nama User</th>
                    <th>email</th>
                </tr>
            </thead>

        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            
                <td><?php echo e($u->id); ?></td>
                <td><?php echo e($u->name); ?></td>
                <td><?php echo e($u->email); ?> </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </tbody>
        </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/admin/pengguna.blade.php ENDPATH**/ ?>