
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- @TODO: replace SET_YOUR_CLIENT_KEY_HERE with your client key -->
    <script type="text/javascript"
      src="https://app.sandbox.midtrans.com/snap/snap.js"
      data-client-key="SB-Mid-client-0rjpbIxnKF4OkuGQ"></script>
    <!-- Note: replace with src="https://app.midtrans.com/snap/snap.js" for Production environment -->
  </head>
<?php $__env->startSection('content'); ?>



<section class="ftco-section ftco-cart">
  <div class="container">
    <div class="row">

      <?php if(count($cartList) == 0): ?>
      <div class="col-md-12 text-center heading-section ftco-animate">
        <h1 class="center">Kosong</h1>
      </div>

      <?php else: ?>
      <div class="col-md-12 ftco-animate">
        <div class="cart-list">
          <table class="table">
            <thead class="thead-primary">
              <tr class="text-center">
                <th>Gambar </th>
                <th>Product</th>
                <th>Price</th>
                <th>Status belanja</th>
                <th>Action</th>
                <th> </th>
              </tr>
            </thead>
            <tbody>
              <?php $__currentLoopData = $cartList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr class="text-center">
               
                  <td><img class="img-fluid" src="<?php echo e(asset('storage/produk/foto/'.$c->foto_produk_cart)); ?>" width="150"></td>

                  <td class="product-name">
                    <h3><?php echo e($c->nama_produk); ?></h3>
                    <p>Kualitas terbaik</p>
                  </td>
                  
                  <td class="price"><?php echo e(number_format($c->harga_produk_cart,2)); ?></td>
                  <td> 
                    <?php if($c->status_pembayaran_cart == 'belum_dibayar'): ?>
                       <div class="alert alert-danger">Belum di bayar</div>
                    <?php endif; ?>
                  </td>
                  
                  <td>
                    <a href="<?php echo e(route('cart.getPembayaran',$c->id_transaksi)); ?>" class="btn btn-info border border-primary mb-3"> Bayar sekarang </a> <br>
                    <a href="<?php echo e(route('cart.hapus',$c->id_transaksi)); ?>" class="btn btn-danger btn-xs">Delete</a></td>
               
              </tr><!-- END TR-->
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>



          <p class="text-center"><a href="shop.php" class="btn btn-default">Continue Shopping</a></p>
          <p class="text-center"><a href="checkout.php" class="btn btn-primary py-3 px-4">Proceed to Checkout</a></p>
          <?php endif; ?>
      

        </div>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/user/cart.blade.php ENDPATH**/ ?>