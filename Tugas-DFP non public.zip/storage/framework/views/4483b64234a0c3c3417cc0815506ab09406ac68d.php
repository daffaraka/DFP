<?php $__env->startSection('content'); ?>

<section class="ftco-section">
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-xl-8 ftco-animate">
          <div class="panel panel-default">
              <div class="panel-heading">
                  <h3>Login User</h3>
                  <p></p>
              </div>
              <div class="panel-body">
                  <form method="post" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                          <label>Email</label>
                          <input type="email" class="form-control" name="email">
                      </div>
                      <div class="form-group">
                          <label>Password</label>
                          <input type="password" class="form-control" name="password">
                      </div>
                      <div class="form-group row mb-0">
                        <div class="col-md-12 ">
                            <button type="submit" class="btn btn-primary btn-block"  style="background-color:#b42a2a">
                                <?php echo e(__('Login')); ?>

                            </button>

                            <?php if(Route::has('password.request')): ?>
                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <p>Don't have an account?</p>
                    <a href="<?php echo e(route('register')); ?>" class="btn btn-primary btn-block"  style="background-color:#b42a2a" name="daftar">
                     Sign Up
                    </a>
                  </form>
              </div>
          </div>
        </div> <!-- .col-md-8 -->
      </div>
    </div>
  </section> <!-- .section -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/auth/login.blade.php ENDPATH**/ ?>