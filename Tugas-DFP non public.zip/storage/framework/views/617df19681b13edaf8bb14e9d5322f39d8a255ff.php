
<?php $__env->startSection('content'); ?>
<section class="ftco-section bg-light">
  <div class="container">
    <div class="row">
        <div class="col-md-4 rounded border border-warning p-2">
          <img src="<?php echo e(asset('storage/produk/foto/'.$getPembayaran->foto_produk_cart)); ?>" height="200px;" class="img-responsive center-block rounded" alt="...">
          
        </div>
        <div class="col-md-8 p-0 bg-white rounded border border-warning">
            <div class="card-header">
             <h3>Segera lakukan pembayaran anda. </h3> </div>
             <div class="card-body">
               <h5>Transaksi akan selesai sebelum tanggal 1 September 2022, pukul 13:40</h5>
               <a href="<?php echo e(route('cart.payNow',$getPembayaran->id_transaksi)); ?>">
                <button class="btn btn-warning mt-5" id="pay-button" >Bayar Sekarang</button> 
               </a>

             </div>

        </div>
          <script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo e(config('midtrans.client_key')); ?>"> </script>

          
      </div>
    </div>
  </div>
</section>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/user/payment.blade.php ENDPATH**/ ?>