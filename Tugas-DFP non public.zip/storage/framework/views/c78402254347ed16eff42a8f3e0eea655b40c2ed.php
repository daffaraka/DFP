<div class="hero-wrap js-fullheight" style="background-image: url(<?php echo e(asset('css/user/images/bg1.jpg')); ?>);">
    <div class="overlay"></div>
    <div class="container">
      <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
          <h3 class="v">LARAVEL NIKE SHOES</h3>
          <h3 class="vr">Since - 2019</h3>
        <div class="col-md-11 ftco-animate text-center">
          <h1 style="text-shadow: #000 2px 5px 2px">LARAVEL NIKE SHOES</h1>
          <h2><span>Wear Your Shoes</span></h2>
        </div>
        <div class="mouse">
                      <a href="#" class="mouse-icon">
                          <div class="mouse-wheel"><span class="ion-ios-arrow-down"></span></div>
                      </a>
                  </div>
      </div>
    </div>
  </div><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/user/partials/banner.blade.php ENDPATH**/ ?>