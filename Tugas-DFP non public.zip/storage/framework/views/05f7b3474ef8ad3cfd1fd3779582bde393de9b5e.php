
<?php $__env->startSection('content-admin'); ?>
<h2>Data Pembelian</h2>

<table class="table table-bordered">
	<thead>
		<tr>
            <th>Id</th>
			<th>Nama Pelanggan</th>
			<th>Tanggal</th>
			<th>Total</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
		
		<tr>
            <td>id pembelian</td>
			<td>nama pelanggan</td>
			<td>tanggal pembelian</td>
			<td>total pembelian</td>
			<td>
            <a href="<?php echo e(route('admin.pembelian-detail')); ?>"class="btn btn-info">D   etail</a>
			</td>
		</tr>
		

	</tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/admin/pembelian.blade.php ENDPATH**/ ?>