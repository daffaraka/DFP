
<?php $__env->startSection('content-admin'); ?>

<h2>Data Produk</h2>

<table class="table table-bordered">
    <thead>
        <tr>
           
            <th>Id</th>
            <th>Nama</th>
            <th>Harga</th>
            <th>Foto</th>
            <th>Aksi</th>
        </tr>
    </thead>

<tbody>
    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      
        <td><?php echo e($p->id_product); ?></td>
        <td><?php echo e($p->nama_produk); ?></td>
        <td>Rp.<?php echo e(number_format($p->harga_produk,2)); ?> </td>
        <td>
            <img src="<?php echo e(asset('storage/produk/foto/'.$p->foto_produk)); ?>" width="150" class="img-responsive center-block">
		</td>
        <td>
            
            <a href="<?php echo e(route('admin.product-edit')); ?>" class="btn btn-warning">Ubah</a>
            <a href="<?php echo e(route('admin.product-hapus',$p->id_product)); ?>" class="btn btn-danger">Hapus</a>
        </td> 
       
       
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</tbody>
</table>

<a href="<?php echo e(route('admin.product-tambah')); ?>" class="btn btn-primary">Tambah Produk</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas-DFP\resources\views/admin/product.blade.php ENDPATH**/ ?>