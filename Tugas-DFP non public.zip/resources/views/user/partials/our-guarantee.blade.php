<section class="ftco-section bg-light ftco-services">
    <div class="container">
        <div class="row justify-content-center mb-3 pb-3">
      <div class="col-md-12 heading-section text-center ftco-animate">
        <h1 class="big">Services</h1>
        <h2>We want you to express yourself</h2>
      </div>
    </div>
    <div class="row">
      <div class="col-md-4 text-center d-flex align-self-stretch ftco-animate">
        <div class="media block-6 services">
          <div class="icon d-flex justify-content-center align-items-center mb-4">
                <span class="flaticon-002-recommended"></span>
          </div>
          <div class="media-body">
            <h3 class="heading">Refund Policy</h3>
          </div>
        </div>      
      </div>
      <div class="col-md-4 text-center d-flex align-self-stretch ftco-animate">
        <div class="media block-6 services">
          <div class="icon d-flex justify-content-center align-items-center mb-4">
                <span class="flaticon-001-box"></span>
          </div>
          <div class="media-body">
            <h3 class="heading">Premium Packaging</h3>
          </div>
        </div>    
      </div>
      <div class="col-md-4 text-center d-flex align-self-stretch ftco-animate">
        <div class="media block-6 services">
          <div class="icon d-flex justify-content-center align-items-center mb-4">
                <span class="flaticon-003-medal"></span>
          </div>
          <div class="media-body">
            <h3 class="heading">Superior Quality</h3>
          </div>
        </div>      
      </div>
    </div>
    </div>
</section>