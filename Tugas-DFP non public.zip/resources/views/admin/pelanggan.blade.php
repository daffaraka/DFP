@extends('admin.layout-admin')
@section('content-admin')
<h2>Data Pelanggan</h2>

<table class="table table-bordered">
	<thead>
		<tr>
			<th>Id</th>
			<th>Nama</th>
			<td>Email</td>
			<th>Telepon</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
		
		<tr>
            <td>id pelanggan</td>
			<td>nama pelanggan</td>
			<td>email pelanggan</td>
			<td>telepon pelanggan</td>
			<td>
				<a href="" class="btn btn-danger">hapus</a>
			</td>
		</tr>

	</tbody>
</table>

@endsection